import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";

/**
 * Velvet Vault guard
 * - If Firebase is configured, enforce verified-auth.
 * - If Firebase isn't configured (demo mode), do NOT hard-redirect (so the site still runs locally/static).
 */
const auth = window.vvAuth;
const firebaseInitError = window.vvFirebaseInitError;

const LOGIN_PATH = "login.html";

function goToLogin(next = location.pathname + location.search) {
  if (!location.pathname.endsWith(LOGIN_PATH)) {
    const url = `${LOGIN_PATH}?next=${encodeURIComponent(next)}`;
    location.replace(url);
  }
}

function wireLogout() {
  const btn = document.querySelector("[data-logout]");
  if (!btn) return;

  btn.addEventListener("click", async (e) => {
    e.preventDefault();
    if (!auth) {
      console.warn("[VelvetVault] Logout clicked, but auth unavailable (demo mode).");
      return;
    }
    try {
      await signOut(auth);
      goToLogin("index.html");
    } catch (err) {
      console.warn("[VelvetVault] signOut failed:", err);
    }
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  wireLogout();

  // Demo mode: allow pages to load without forcing login.
  if (!auth) {
    if (firebaseInitError) {
      console.warn("[VelvetVault] Firebase unavailable; running in demo mode.", firebaseInitError);
    } else {
      console.warn("[VelvetVault] Firebase auth not detected; running in demo mode.");
    }
    return;
  }

  // Auth available: enforce verified user
  try {
    if (typeof auth.authStateReady === "function") {
      await auth.authStateReady();
    }
  } catch (_) {
    // ignore
  }

  onAuthStateChanged(auth, (user) => {
    if (!user) return goToLogin();
    if (user.emailVerified === false) return goToLogin();
  });
});
