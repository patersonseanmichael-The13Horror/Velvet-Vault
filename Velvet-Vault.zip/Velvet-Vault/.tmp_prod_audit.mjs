import { chromium } from 'playwright';

const base = 'http://127.0.0.1:4173';
const pages = [
  'index.html',
  'login.html',
  'members.html',
  'slots.html',
  'roulette.html',
  'blackjack.html',
  'poker.html',
  'ledger.html'
];

const authModule = `
const AUTH_KEY = '__vv_mock_auth_state';
function seedUser() {
  try {
    if (localStorage.getItem(AUTH_KEY) === 'signedout') return null;
  } catch {}
  return { uid: 'audit-user', emailVerified: true, email: 'audit@velvet.test' };
}
function ensureAuth(){
  if(!globalThis.__vvAuth){
    globalThis.__vvAuth = {
      currentUser: seedUser(),
      _listeners: new Set(),
      authStateReady: async () => {}
    };
  }
  return globalThis.__vvAuth;
}
function notify(auth){
  const list = Array.from(auth._listeners || []);
  for (const fn of list){
    try { fn(auth.currentUser); } catch {}
  }
}
export function getAuth(){ return ensureAuth(); }
export function onAuthStateChanged(auth, cb){
  if(!auth._listeners) auth._listeners = new Set();
  auth._listeners.add(cb);
  queueMicrotask(() => { try { cb(auth.currentUser); } catch {} });
  return () => auth._listeners.delete(cb);
}
export async function signOut(auth){
  auth.currentUser = null;
  try { localStorage.setItem(AUTH_KEY, 'signedout'); } catch {}
  notify(auth);
}
export async function createUserWithEmailAndPassword(auth, email){
  const uid = String(email || 'audit-user').replace(/[^a-z0-9]/gi, '-').slice(0, 28) || 'audit-user';
  const user = { uid, email: String(email || ''), emailVerified: false };
  auth.currentUser = user;
  try { localStorage.setItem(AUTH_KEY, 'signedin'); } catch {}
  notify(auth);
  return { user };
}
export async function signInWithEmailAndPassword(auth, email){
  const uid = String(email || 'audit-user').replace(/[^a-z0-9]/gi, '-').slice(0, 28) || 'audit-user';
  const user = { uid, email: String(email || ''), emailVerified: true };
  auth.currentUser = user;
  try { localStorage.setItem(AUTH_KEY, 'signedin'); } catch {}
  notify(auth);
  return { user };
}
export async function sendEmailVerification(user){
  if (user) user.emailVerified = true;
}
`;

const appModule = `export function initializeApp(cfg){ return { cfg }; }`;

const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 390, height: 844 } });

await context.route('https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js', (route) => {
  route.fulfill({ status: 200, contentType: 'application/javascript', body: authModule });
});
await context.route('https://www.gstatic.com/firebasejs/12.9.0/firebase-app.js', (route) => {
  route.fulfill({ status: 200, contentType: 'application/javascript', body: appModule });
});

const results = [];

for (const file of pages) {
  const page = await context.newPage();
  const errors = [];

  page.on('console', (msg) => {
    if (msg.type() !== 'error') return;
    const t = msg.text();
    if (t.includes('Failed to load resource')) return;
    errors.push(`console: ${t}`);
  });
  page.on('pageerror', (e) => {
    errors.push(`pageerror: ${e.message}`);
  });
  page.on('requestfailed', (req) => {
    const url = req.url();
    const err = req.failure()?.errorText || 'unknown';
    if (err.includes('ERR_ABORTED')) return;
    if (url.includes('fonts.googleapis.com') || url.includes('fonts.gstatic.com')) return;
    errors.push(`requestfailed: ${url} :: ${err}`);
  });

  const url = `${base}/${file}`;
  await page.goto(url, { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(700);

  const metrics = await page.evaluate(() => {
    const doc = document.documentElement;
    const body = document.body;
    const overflowX = Math.max(doc.scrollWidth - doc.clientWidth, body.scrollWidth - body.clientWidth);
    return {
      overflowX,
      path: location.pathname,
      search: location.search
    };
  });

  results.push({ file, finalUrl: page.url(), metrics, errors });
  await page.close();
}

await context.close();
await browser.close();

console.log(JSON.stringify({ results }, null, 2));
