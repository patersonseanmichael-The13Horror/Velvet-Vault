/* Velvet Vault Roulette Engine */
(function () {
  /* =========================
     SOUND
     ========================= */
  let AC = null;
  function audioOn() {
    if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)();
    if (AC.state === "suspended") AC.resume();
  }
  function beep(freq = 440, ms = 60, type = "sine", gain = 0.05) {
    if (!AC) return;
    const o = AC.createOscillator();
    const g = AC.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = gain;
    o.connect(g);
    g.connect(AC.destination);
    o.start();
    setTimeout(() => o.stop(), ms);
  }
  function chime() { beep(660, 70, "sine", 0.05); setTimeout(() => beep(880, 90, "sine", 0.05), 80); }
  function thud() { beep(140, 90, "triangle", 0.06); }
  function tick() { beep(520, 22, "square", 0.018); }

  /* =========================
     DOM
     ========================= */
  const walletBalEl = document.getElementById("walletBal");
  const logEl = document.getElementById("log");
  const layoutEl = document.getElementById("layout");
  const dozensEl = document.getElementById("dozens");
  const evensEl = document.getElementById("evens");

  const totalBetEl = document.getElementById("totalBet");
  const chipValEl = document.getElementById("chipVal");
  const chipAmtEl = document.getElementById("chipAmt");
  const lastResultEl = document.getElementById("lastResult");
  const statusEl = document.getElementById("status");

  const chipSlider = document.getElementById("chipSlider");
  const spinBtn = document.getElementById("spinBtn");
  const clearBtn = document.getElementById("clearBtn");

  const wheelRing = document.getElementById("wheelRing");
  const wheelWrap = document.querySelector(".wheelWrap");
  const ball = document.getElementById("ball");

  const raceOrderEl = document.getElementById("raceOrder");
  const neighborSelect = document.getElementById("neighborSelect");
  const neighborsBtn = document.getElementById("neighborsBtn");
  const voisinsBtn = document.getElementById("voisinsBtn");
  const tiersBtn = document.getElementById("tiersBtn");
  const orphelinsBtn = document.getElementById("orphelinsBtn");

  const rtStackNeighbors = document.getElementById("rtStackNeighbors");
  const rtStackVoisins = document.getElementById("rtStackVoisins");
  const rtStackTiers = document.getElementById("rtStackTiers");
  const rtStackOrphelins = document.getElementById("rtStackOrphelins");

  /* =========================
     WALLET
     ========================= */
  function renderWallet() {
    if (!window.VaultEngine?.user) return;
    walletBalEl.textContent = window.VaultEngine.formatGold(window.VaultEngine.getBalance());
  }
  const wWait = setInterval(() => {
    if (window.VaultEngine) {
      clearInterval(wWait);
      window.VaultEngine.subscribe(renderWallet);
      renderWallet();
    }
  }, 100);

  function requireWallet() {
    if (!window.VaultEngine?.user) {
      logEl.textContent = "Connecting to the vault...";
      return false;
    }
    return true;
  }
  function debit(amount, note) {
    if (!requireWallet()) return false;
    const ok = window.VaultEngine.debit(amount, note);
    if (!ok) {
      const bal = window.VaultEngine.getBalance?.() ?? 0;
      logEl.innerHTML = `Insufficient funds. Wallet: <b>${window.VaultEngine.formatGold(bal)}</b>`;
      thud();
      return false;
    }
    return true;
  }
  function credit(amount, note) {
    if (!window.VaultEngine?.user) return;
    window.VaultEngine.credit(amount, note);
  }

  /* =========================
     WHEEL DATA
     ========================= */
  const WHEEL_ORDER = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
  const RED_SET = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
  const POCKET_SIZE = 360 / WHEEL_ORDER.length;

  const RACETRACK_SETS = {
    voisins: [22, 18, 29, 7, 28, 12, 35, 3, 26, 0, 32, 15, 19, 4, 21, 2, 25],
    tiers: [27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33],
    orphelins: [1, 20, 14, 31, 9, 17, 34, 6]
  };

  function colorOf(n) {
    if (n === 0) return "green";
    return RED_SET.has(n) ? "red" : "black";
  }

  /* =========================
     BETS
     ========================= */
  const PAYOUTS = {
    straight: 35,
    split: 17,
    street: 11,
    corner: 8,
    dozen: 2,
    even: 1,
    racetrack: 35
  };

  const BETS = new Map();
  function key(type, id) { return `${type}:${id}`; }

  function totalBet() {
    let t = 0;
    for (const b of BETS.values()) t += b.amount;
    return t;
  }

  function mkStack() {
    const s = document.createElement("div");
    s.className = "chipStack";
    return s;
  }

  function addChipVisual(stack) {
    if (!stack) return;
    const c = document.createElement("div");
    c.className = `chip ${Math.random() > 0.5 ? "g" : ""}`.trim();
    stack.appendChild(c);
    if (typeof c.animate === "function") {
      c.animate(
        [
          { transform: "translateY(-14px) scale(0.84)", opacity: 0.05 },
          { transform: "translateY(0) scale(1)", opacity: 1 }
        ],
        { duration: 220, easing: "cubic-bezier(.2,.9,.2,1)" }
      );
    }
    while (stack.children.length > 10) stack.removeChild(stack.firstChild);
  }

  let chipValue = Number(chipSlider?.value || 100);
  chipSlider?.addEventListener("input", () => {
    chipValue = Number(chipSlider.value || 100);
    chipValEl.textContent = chipValue;
    chipAmtEl.textContent = chipValue;
  });

  let spinning = false;

  function placeBet(type, id, nums, stack) {
    if (spinning) {
      logEl.textContent = "No more bets";
      return;
    }

    const k = key(type, id);
    const existing = BETS.get(k);
    if (existing) {
      existing.amount += chipValue;
      if (stack && !existing.stacks.includes(stack)) existing.stacks.push(stack);
    } else {
      BETS.set(k, {
        type,
        nums: new Set(nums),
        amount: chipValue,
        stacks: stack ? [stack] : []
      });
    }

    addChipVisual(stack);
    totalBetEl.textContent = totalBet();
  }

  function placeRacetrackBet(id, numbers, label, stack) {
    placeBet("racetrack", id, numbers, stack);
    if (!spinning) {
      logEl.innerHTML = `${label}: <b>${numbers.join(", ")}</b>`;
    }
  }

  /* =========================
     BOARD UI
     ========================= */
  function mkNumberCell(n) {
    const d = document.createElement("div");
    const c = colorOf(n);
    d.className = `cell ${c === "red" ? "nRed" : c === "black" ? "nBlack" : "nGreen"}`;
    d.dataset.number = String(n);
    d.textContent = String(n);
    const stack = mkStack();
    d.appendChild(stack);
    d.addEventListener("click", () => {
      audioOn();
      tick();
      placeBet("straight", String(n), [n], stack);
    });
    return d;
  }

  function mkStreetCell(start) {
    const d = document.createElement("div");
    d.className = "cell label";
    d.textContent = "ST";
    const stack = mkStack();
    d.appendChild(stack);
    d.title = `Street ${start}-${start + 2}`;
    d.addEventListener("click", () => {
      audioOn();
      tick();
      placeBet("street", String(start), [start, start + 1, start + 2], stack);
    });
    return d;
  }

  function mkSpot(type, id, nums, label) {
    const d = document.createElement("div");
    d.className = "spot";
    d.innerHTML = `<small>${label || type}</small>`;
    const stack = mkStack();
    d.appendChild(stack);
    d.addEventListener("click", () => {
      audioOn();
      tick();
      placeBet(type, id, nums, stack);
    });
    return d;
  }

  function buildLayout() {
    layoutEl.innerHTML = "";

    const rows = [];
    for (let r = 0; r < 12; r += 1) {
      const start = 1 + r * 3;
      rows.push([start, start + 1, start + 2]);
    }

    rows.forEach((nums, rIdx) => {
      layoutEl.appendChild(mkStreetCell(nums[0]));
      layoutEl.appendChild(mkNumberCell(nums[0]));
      layoutEl.appendChild(mkSpot("split", `${nums[0]}-${nums[1]}`, [nums[0], nums[1]], "SPLIT"));
      layoutEl.appendChild(mkNumberCell(nums[1]));
      layoutEl.appendChild(mkSpot("split", `${nums[1]}-${nums[2]}`, [nums[1], nums[2]], "SPLIT"));
      layoutEl.appendChild(mkNumberCell(nums[2]));

      if (rIdx < rows.length - 1) {
        const below = rows[rIdx + 1];
        const gap = document.createElement("div");
        gap.className = "rowGap";
        layoutEl.appendChild(gap);
        layoutEl.appendChild(Object.assign(document.createElement("div"), { className: "cell label", textContent: "" }));
        layoutEl.appendChild(mkSpot("split", `${nums[0]}-${below[0]}`, [nums[0], below[0]], "V"));
        layoutEl.appendChild(mkSpot("corner", `${nums[0]}-${nums[1]}-${below[0]}-${below[1]}`, [nums[0], nums[1], below[0], below[1]], "C"));
        layoutEl.appendChild(mkSpot("split", `${nums[1]}-${below[1]}`, [nums[1], below[1]], "V"));
        layoutEl.appendChild(mkSpot("corner", `${nums[1]}-${nums[2]}-${below[1]}-${below[2]}`, [nums[1], nums[2], below[1], below[2]], "C"));
        layoutEl.appendChild(mkSpot("split", `${nums[2]}-${below[2]}`, [nums[2], below[2]], "V"));
      }
    });

    dozensEl.innerHTML = "";
    const d1 = mkSpot("dozen", "1", [...Array(12)].map((_, i) => i + 1), "1st 12");
    const d2 = mkSpot("dozen", "2", [...Array(12)].map((_, i) => i + 13), "2nd 12");
    const d3 = mkSpot("dozen", "3", [...Array(12)].map((_, i) => i + 25), "3rd 12");
    d1.classList.add("cell");
    d2.classList.add("cell");
    d3.classList.add("cell");
    dozensEl.appendChild(d1);
    dozensEl.appendChild(d2);
    dozensEl.appendChild(d3);

    evensEl.innerHTML = "";
    const low = mkSpot("even", "low", [...Array(18)].map((_, i) => i + 1), "1-18");
    const even = mkSpot("even", "even", [...Array(18)].map((_, i) => 2 * (i + 1)).filter((n) => n <= 36), "EVEN");
    const red = mkSpot("even", "red", [...RED_SET], "RED");
    const black = mkSpot("even", "black", [...Array(36)].map((_, i) => i + 1).filter((n) => !RED_SET.has(n)), "BLACK");
    const odd = mkSpot("even", "odd", [...Array(18)].map((_, i) => 2 * i + 1), "ODD");
    const high = mkSpot("even", "high", [...Array(18)].map((_, i) => i + 19), "19-36");
    [low, even, red, black, odd, high].forEach((x) => {
      x.classList.add("cell");
      evensEl.appendChild(x);
    });

    totalBetEl.textContent = "0";
  }

  function clearBets() {
    BETS.clear();
    document.querySelectorAll(".chipStack").forEach((s) => { s.innerHTML = ""; });
    totalBetEl.textContent = "0";
    logEl.textContent = "Bets cleared.";
  }

  /* =========================
     RACETRACK
     ========================= */
  function wheelNeighbors(center, radius = 2) {
    const idx = WHEEL_ORDER.indexOf(center);
    if (idx < 0) return [center];
    const nums = [];
    for (let i = -radius; i <= radius; i += 1) {
      const pos = (idx + i + WHEEL_ORDER.length) % WHEEL_ORDER.length;
      nums.push(WHEEL_ORDER[pos]);
    }
    return nums;
  }

  function initRacetrack() {
    raceOrderEl.innerHTML = "";
    WHEEL_ORDER.forEach((n) => {
      const s = document.createElement("span");
      s.className = `num ${n === 0 ? "g" : RED_SET.has(n) ? "r" : "b"}`;
      s.textContent = String(n);
      raceOrderEl.appendChild(s);
    });

    neighborSelect.innerHTML = "";
    WHEEL_ORDER.forEach((n) => {
      const opt = document.createElement("option");
      opt.value = String(n);
      opt.textContent = String(n);
      neighborSelect.appendChild(opt);
    });

    neighborsBtn.addEventListener("click", () => {
      audioOn();
      const center = Number(neighborSelect.value || 0);
      const nums = wheelNeighbors(center, 2);
      placeRacetrackBet(`neighbors-${center}`, nums, `Neighbours ${center}`, rtStackNeighbors);
    });

    voisinsBtn.addEventListener("click", () => {
      audioOn();
      placeRacetrackBet("voisins", RACETRACK_SETS.voisins, "Voisins", rtStackVoisins);
    });

    tiersBtn.addEventListener("click", () => {
      audioOn();
      placeRacetrackBet("tiers", RACETRACK_SETS.tiers, "Tiers", rtStackTiers);
    });

    orphelinsBtn.addEventListener("click", () => {
      audioOn();
      placeRacetrackBet("orphelins", RACETRACK_SETS.orphelins, "Orphelins", rtStackOrphelins);
    });
  }

  /* =========================
     PHYSICS + FX
     ========================= */
  const bettingZones = [layoutEl, dozensEl, evensEl, raceOrderEl, neighborSelect, neighborsBtn, voisinsBtn, tiersBtn, orphelinsBtn];
  let wheelDirection = 1;
  let wheelRotation = 0;
  let ballOrbitAngle = 0;
  let rafId = 0;
  let spinState = null;

  const ballShadow = document.createElement("div");
  ballShadow.style.position = "absolute";
  ballShadow.style.left = "50%";
  ballShadow.style.top = "50%";
  ballShadow.style.width = "18px";
  ballShadow.style.height = "8px";
  ballShadow.style.borderRadius = "999px";
  ballShadow.style.background = "rgba(0,0,0,0.42)";
  ballShadow.style.filter = "blur(2px)";
  ballShadow.style.pointerEvents = "none";
  ballShadow.style.zIndex = "2";
  wheelWrap?.appendChild(ballShadow);

  function normalizeDeg(d) {
    return ((d % 360) + 360) % 360;
  }

  function secureRandomInt(maxExclusive) {
    if (maxExclusive <= 0) return 0;
    if (window.crypto?.getRandomValues) {
      const span = 0x100000000;
      const limit = span - (span % maxExclusive);
      const arr = new Uint32Array(1);
      do {
        window.crypto.getRandomValues(arr);
      } while (arr[0] >= limit);
      return arr[0] % maxExclusive;
    }
    return Math.floor(Math.random() * maxExclusive);
  }
  function secureRandomRange(min, max) {
    return min + secureRandomInt((max - min) + 1);
  }
  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }
  function easingOutCubic(x) { return 1 - Math.pow(1 - x, 3); }
  function easingOutQuart(x) { return 1 - Math.pow(1 - x, 4); }

  function pocketAngleForNumber(n) {
    const idx = WHEEL_ORDER.indexOf(n);
    return idx * POCKET_SIZE;
  }

  function pickBallEndAngle(startBall, wheelEnd, winAngle, ballDir) {
    const baseTarget = wheelEnd + winAngle;
    const minAbs = 4200;
    const maxAbs = 7600;
    const baseDelta = baseTarget - startBall;

    let kMin;
    let kMax;
    if (ballDir > 0) {
      kMin = Math.ceil((minAbs - baseDelta) / 360);
      kMax = Math.floor((maxAbs - baseDelta) / 360);
    } else {
      kMin = Math.ceil((-maxAbs - baseDelta) / 360);
      kMax = Math.floor((-minAbs - baseDelta) / 360);
    }

    if (kMin > kMax) {
      const fallback = ballDir > 0
        ? Math.ceil((minAbs - baseDelta) / 360)
        : Math.floor((-minAbs - baseDelta) / 360);
      return baseTarget + (fallback * 360);
    }
    return baseTarget + (secureRandomRange(kMin, kMax) * 360);
  }

  function setBettingInteractive(enabled) {
    const mode = enabled ? "auto" : "none";
    bettingZones.forEach((zone) => {
      if (zone) zone.style.pointerEvents = mode;
    });
  }

  function buildWheelPockets() {
    wheelRing.querySelectorAll(".wheelPocket").forEach((n) => n.remove());
    WHEEL_ORDER.forEach((num, idx) => {
      const p = document.createElement("div");
      p.className = "wheelPocket";
      p.dataset.number = String(num);
      p.style.setProperty("--pocketAngle", `${idx * POCKET_SIZE}deg`);
      wheelRing.appendChild(p);
    });
  }

  function buildWheelNumbers() {
    wheelRing.innerHTML = "";

    WHEEL_ORDER.forEach((n, i) => {
      const seg = document.createElement("div");
      seg.className = `wheelNum ${colorOf(n)}`;
      seg.style.transform =
        `rotate(${i * (360 / WHEEL_ORDER.length)}deg) translateY(-48%)`;

      seg.textContent = n;
      wheelRing.appendChild(seg);
    });
  }

  function flashWinningNumber(win) {
    const boardCell = layoutEl.querySelector(`.cell[data-number="${win}"]`);
    const pocket = wheelRing.querySelector(`.wheelPocket[data-number="${win}"]`);

    [boardCell, pocket].forEach((el) => {
      if (!el) return;
      el.classList.remove("winFlash");
      void el.offsetWidth;
      el.classList.add("winFlash");
      setTimeout(() => el.classList.remove("winFlash"), 1500);
    });
  }

  function resolvePayout(win) {
    let payout = 0;
    for (const b of BETS.values()) {
      if (b.nums.has(win)) {
        const mult = PAYOUTS[b.type] ?? 0;
        payout += b.amount * (mult + 1);
      }
    }
    return payout;
  }

  function winningStacks(win) {
    const stacks = [];
    BETS.forEach((b) => {
      if (!b.nums.has(win)) return;
      (b.stacks || []).forEach((s) => {
        if (s && !stacks.includes(s)) stacks.push(s);
      });
    });
    return stacks;
  }

  function flyChipsToWallet(stacks) {
    if (!walletBalEl || !stacks.length) return;
    const dest = walletBalEl.getBoundingClientRect();
    const destX = dest.left + (dest.width / 2);
    const destY = dest.top + (dest.height / 2);

    let i = 0;
    stacks.forEach((stack) => {
      const r = stack.getBoundingClientRect();
      const sx = r.left + (r.width / 2);
      const sy = r.top + (r.height / 2);

      for (let n = 0; n < 3; n += 1) {
        const chip = document.createElement("div");
        chip.className = `chipFlight ${(i + n) % 2 ? "g" : ""}`.trim();
        chip.style.left = `${sx}px`;
        chip.style.top = `${sy}px`;
        document.body.appendChild(chip);

        const dx = destX - sx + (Math.random() * 24 - 12);
        const dy = destY - sy + (Math.random() * 18 - 9);

        chip.animate(
          [
            { transform: "translate(-50%,-50%) scale(1)", opacity: 1 },
            { transform: `translate(${dx - 50}px, ${dy - 50}px) scale(0.2)`, opacity: 0 }
          ],
          {
            duration: 560 + (n * 80),
            easing: "cubic-bezier(.15,.92,.15,1)",
            fill: "forwards"
          }
        ).onfinish = () => chip.remove();
      }
      i += 1;
    });
  }

  function maybePocketTick() {
    if (!spinState) return;
    const rel = normalizeDeg(ballOrbitAngle - wheelRotation);
    const idx = Math.floor(rel / POCKET_SIZE);
    const now = performance.now();
    if (idx !== spinState.lastPocketIdx && now - spinState.lastTickAt > 14) {
      tick();
      spinState.lastPocketIdx = idx;
      spinState.lastTickAt = now;
    }
  }

  async function spin() {
    audioOn();
    if (spinning) return;

    const wager = totalBet();
    if (wager <= 0) {
      logEl.textContent = "Place a bet first.";
      thud();
      return;
    }
    if (!debit(wager, "roulette-spin")) return;

    spinning = true;
    spinBtn.disabled = true;
    clearBtn.disabled = true;
    setBettingInteractive(false);
    statusEl.textContent = "SPINNING";
    logEl.innerHTML = "Spinning... <b>No more bets</b>.";

    const win = WHEEL_ORDER[secureRandomInt(WHEEL_ORDER.length)];
    const winAngle = pocketAngleForNumber(win);
    wheelDirection *= -1;
    const ballDirection = -wheelDirection;
    const spinMs = secureRandomRange(5600, 7800);

    const wheelStart = wheelRotation;
    const ballStart = ballOrbitAngle;
    const wheelEnd = wheelStart + (wheelDirection * ((secureRandomRange(10, 14) * 360) + secureRandomRange(30, 170)));
    const ballEnd = pickBallEndAngle(ballStart, wheelEnd, winAngle, ballDirection);

    const bounceBursts = Array.from({ length: secureRandomRange(2, 4) }, () => ({
      t: Math.random() * 0.82 + 0.1,
      amp: Math.random() * 1.3 + 0.6,
      freq: secureRandomRange(16, 28)
    })).sort((a, b) => a.t - b.t);

    const spinStartedAt = performance.now();
    spinState = { lastPocketIdx: -1, lastTickAt: 0, nearEndCue: false };

    const runPhysics = (ts) => {
      const tRaw = Math.min(1, (ts - spinStartedAt) / spinMs);
      const wheelT = easingOutCubic(tRaw);
      const ballT = easingOutQuart(tRaw);

      wheelRotation = wheelStart + ((wheelEnd - wheelStart) * wheelT);
      ballOrbitAngle = ballStart + ((ballEnd - ballStart) * ballT);

      const inwardDrop = 48 - (10 * ballT);
      let bounceJitter = 0;
      for (const b of bounceBursts) {
        const dt = tRaw - b.t;
        if (dt < 0 || dt > 0.16) continue;
        const decay = 1 - (dt / 0.16);
        bounceJitter += Math.sin(dt * b.freq * Math.PI) * b.amp * decay;
      }
      const radius = Math.max(37.6, inwardDrop + bounceJitter);

      const wheelSpeed = Math.abs((wheelEnd - wheelStart) * (1 - tRaw) / (spinMs / 1000));
      const ballSpeed = Math.abs((ballEnd - ballStart) * (1 - tRaw) / (spinMs / 1000));
      const blurPx = Math.min(3.2, (wheelSpeed + ballSpeed) / 900);

      wheelRing.style.transform = `rotate(${wheelRotation}deg)`;
      ball.style.setProperty("--a", `${ballOrbitAngle}deg`);
      ball.style.setProperty("--r", `${radius}%`);
      ball.style.boxShadow = `0 0 ${8 + (blurPx * 5)}px rgba(255,255,255,0.38), 0 0 ${14 + (blurPx * 7)}px rgba(0,255,154,0.25)`;
      ball.style.filter = `blur(${blurPx}px)`;
      wheelRing.style.boxShadow = `inset 0 0 30px rgba(0,0,0,0.65), 0 0 ${10 + blurPx * 8}px rgba(255,35,61,.18), 0 0 ${10 + blurPx * 8}px rgba(0,255,154,.15)`;

      ballShadow.style.transform = `translate(-50%, -50%) rotate(${ballOrbitAngle}deg) translateX(${Math.max(30, radius - 7)}%)`;
      ballShadow.style.opacity = String(Math.min(0.55, 0.22 + blurPx / 4));

      maybePocketTick();
      if (!spinState.nearEndCue && tRaw > 0.9) {
        spinState.nearEndCue = true;
        thud();
        setTimeout(chime, 90);
      }

      if (tRaw < 1) {
        rafId = requestAnimationFrame(runPhysics);
        return;
      }

      ball.style.filter = "none";
      ball.style.boxShadow = "0 0 10px rgba(255,255,255,0.25), 0 0 18px rgba(0,255,154,0.10)";
      ballShadow.style.opacity = "0.3";
      wheelRing.style.boxShadow = "inset 0 0 30px rgba(0,0,0,0.65)";
    };

    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(runPhysics);

    await sleep(spinMs + 140);

    lastResultEl.innerHTML = `${win} <span class="${colorOf(win) === "red" ? "r" : ""}">${colorOf(win).toUpperCase()}</span>`;

    flashWinningNumber(win);

    const payout = resolvePayout(win);
    if (payout > 0) {
      const stacks = winningStacks(win);
      credit(payout, "roulette-payout");
      flyChipsToWallet(stacks);
      logEl.innerHTML = `Result: <b>${win}</b>. You win <b>${payout}</b> GOLD.`;
    } else {
      logEl.innerHTML = `Result: <b>${win}</b>. Dealer takes it.`;
    }

    renderWallet();
    clearBets();

    statusEl.textContent = "READY";
    spinning = false;
    spinBtn.disabled = false;
    clearBtn.disabled = false;
    setBettingInteractive(true);
    spinState = null;
  }

  buildLayout();
  initRacetrack();
  buildWheelNumbers();
  buildWheelPockets();

  spinBtn?.addEventListener("click", spin);
  clearBtn?.addEventListener("click", clearBets);
})();
